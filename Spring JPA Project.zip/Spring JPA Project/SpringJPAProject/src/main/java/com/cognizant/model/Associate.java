package com.cognizant.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.apache.tomcat.util.codec.binary.Base64;
import org.hibernate.annotations.BatchSize;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "Associates")
@Component

public class Associate {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) //
	private Integer id;
	private String name;
	private String password;
	private Integer age;
	private String city;
	private String work;
	private String gender;
	private String agree;

	@Lob
	private byte[] associatePic;

	public Associate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Associate(Integer id, String name, String password, Integer age, String city, String work, String gender,
			String agree) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.age = age;
		this.city = city;
		this.work = work;
		this.gender = gender;
		this.agree = agree;
	}

	public Associate(Integer id, String name, String password, Integer age, String city, String work, String gender,
			String agree, byte[] associatePic) {
		super();
		this.id = id;
		this.name = name;
		this.password = password;
		this.age = age;
		this.city = city;
		this.work = work;
		this.gender = gender;
		this.agree = agree;
		this.associatePic = associatePic;
	}
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getWork() {
		return work;
	}

	public void setWork(String work) {
		this.work = work;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAgree() {
		return agree;
	}

	public void setAgree(String agree) {
		this.agree = agree;
	}

	public byte[] getAssociatePic() {
		return associatePic;
	}

	public void setAssociatePic(byte[] associatePic) {
		this.associatePic = associatePic;
	}
	public String getAssociatePicture() {
		return Base64.encodeBase64String(associatePic);
	}

	@Override
	public String toString() {
		return "Associate [id=" + id + ", name=" + name + ", password=" + password + ", age=" + age + ", city=" + city
				+ ", work=" + work + ", gender=" + gender + ", agree=" + agree + ", associatePic="
				+ Arrays.toString(associatePic) + "]";
	}

	

	
}

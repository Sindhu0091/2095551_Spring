package com.cognizant.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import  com.cognizant.repository.AssociateRepository;

import com.cognizant.model.Associate;

@Service
public class AssociateDaoImpl implements AssociateDao {
	
	@Autowired
	AssociateRepository AssociateRepository; 

	@Override
	public void addAssociate(Associate associate) {
		// TODO Auto-generated method stub
		AssociateRepository.save(associate);		

	}

	@Override
	public List<Associate> getAllAssociate() {
		// TODO Auto-generated method stub
	 	List<Associate> associateList =  AssociateRepository.findAll();
		return associateList;
	}

	@Override
	public Associate getAssociateById(int id) {
		// TODO Auto-generated method stub
		Associate associate = AssociateRepository.getById(id);
		return associate;
	
	}

	@Override
	public void updateAssociate(Associate associate) {
		// TODO Auto-generated method stub
		AssociateRepository.save(associate);
	}

	@Override
	public void deleteAssociate(int id) {
		// TODO Auto-generated method stub
		AssociateRepository.deleteById(id);
	}

	@Override
	public Associate validateAssociate(Associate associate) {
		// TODO Auto-generated method stub
		Associate associate1 = AssociateRepository.findByLoginData(associate.getName(), associate.getPassword());
		return associate1;
		
	}

}

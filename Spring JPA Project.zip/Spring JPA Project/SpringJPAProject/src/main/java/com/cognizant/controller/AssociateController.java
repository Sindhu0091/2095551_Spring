package com.cognizant.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.tags.form.RadioButtonTag;
import org.springframework.web.servlet.tags.form.RadioButtonsTag;

import com.cognizant.dao.AssociateDao;

import com.cognizant.model.Associate;

@Controller
public class AssociateController {

	@Autowired
	Associate associate;

	@Autowired
	AssociateDao associateDao;

	String msg;

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("associate", associate);
		model.addAttribute("msg", msg);
		System.out.println(associate);
		return "index";
	}

	@RequestMapping("validate")
	public String validateAssociate(@ModelAttribute("associate") Associate associate, Model mv, HttpSession session) {

		Associate associate1 = associateDao.validateAssociate(associate);
		if (associate1 != null) {
			msg = "Login Successfull";
			session.setAttribute("associate", associate.getName());
			System.out.println("Login Successfull");
			return "redirect:/getall";
		} else {
			System.out.println("Login Failed");
			msg = "Login Failed";
			return "redirect:/home";
		}

	}

	@RequestMapping("/registeration")
	public String showRegisterationForm(Model model) {
		model.addAttribute("associate", associate);

		return "registeration";

	}

	@RequestMapping("submitform")
	public ModelAndView saveAssociate(@ModelAttribute("associate") Associate associate, ModelAndView mv,
			@RequestParam("Pic") MultipartFile file) throws IOException {

		System.out.println(associate);
		System.out.println("In Save Associate");
		byte[] associatePic = file.getBytes();
		associate.setAssociatePic(associatePic);
		associateDao.addAssociate(associate);
		mv.addObject("msg", "Associate Added Successfully");
		mv.addObject("associate", associate);
		mv.setViewName("registeration");
		return mv;
	}

	@RequestMapping("getall")
	public ModelAndView getAllAssociate(ModelAndView mv) {
		List<Associate> associateList = associateDao.getAllAssociate();
		mv.addObject("associates", associateList);
		mv.addObject("msg", msg);
		mv.setViewName("viewassociate");
		return mv;
	}

	@RequestMapping("getassociateform")
	public String getAssociateForm() {
		return "getassociate";
	}

	@RequestMapping("getbyid")
	public ModelAndView getById(@RequestParam("id") int id, ModelAndView mv) {
		Associate associate = associateDao.getAssociateById(id);
		mv.addObject("associate", associate);
		mv.setViewName("showassociate");
		return mv;
	}

	@RequestMapping("updateassociate/{id}")
	public String getUpdateAssociate(@PathVariable int id, Model m) {

		Associate associate = associateDao.getAssociateById(id);
		System.out.println("In Controller : " + associate);
		m.addAttribute("associate", associate);
		return "updateform";

	}

	@RequestMapping("saveupdate")
	public String saveUpdate(@ModelAttribute("associate") Associate associate) {
		associateDao.updateAssociate(associate);
		return "redirect:/getall";

	}

	@RequestMapping("deleteassociate/{id}")
	public String deleteAssociate(@PathVariable int id) {
		associateDao.deleteAssociate(id);
		return "redirect:/getall";
	}
}
package com.cognizant.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Associate;


@Repository
public interface AssociateRepository extends JpaRepository<Associate, Integer>{
	
	@Query("select a from Associate a where a.name=(:name) and a.password=(:password)")
	Associate findByLoginData(String name, String password);

}

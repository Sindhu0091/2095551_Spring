package com.cognizant.dao;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.model.Associate;

@Service
public interface AssociateDao {

		public void addAssociate(Associate associate);
		public List<Associate> getAllAssociate();
		public Associate getAssociateById(int id);
		public void updateAssociate(Associate associate);
		public void deleteAssociate(int id);
		public Associate validateAssociate(Associate associate);
	}
